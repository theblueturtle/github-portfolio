/**********************************************************************
File: StateMachine.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;

public abstract class StateMachine : MonoBehaviour
{
    private State currentState;
    
    private void Update()
    {
       currentState?.Tick(Time.deltaTime);
    }

    public void SwitchState(State newState)
    {
        currentState?.Exit();
        currentState = newState;
        currentState?.Enter();
    }
}