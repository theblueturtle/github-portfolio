/**********************************************************************
File: PlayerCrouchState.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using System;
using UnityEngine;

public class PlayerCrouchState : PlayerBaseState
{
    private readonly int CrouchBlendTreeHash = Animator.StringToHash("CrouchBlendTree");
    private readonly int CrouchBlendParamHash = Animator.StringToHash("CrouchBlend");
    private const float Constant_CrossFadeDuration = 0.05f;
    private string stateID = "CCH";

    public PlayerCrouchState(PlayerStateMachine stateMachine) : base(stateMachine) { }

    private void Log(string message)
    {
        if (stateMachine.DebugLogger != null)
        {
            //stateMachine.DebugLogger.LogStateMessage(stateID, message);
        }
        else { Debug.LogError("Logger not set for = " + stateMachine.gameObject.name); }
    }

    public override void Enter()
    {
        Log("Enter()");
        stateMachine.ReportActiveState("Crouching");

        stateMachine.PlayerInputReader.CrouchEvent += OnCrouch;
        stateMachine.Animator.CrossFadeInFixedTime(CrouchBlendTreeHash, stateMachine.AnimationSmoothing);
    }

    public override void Tick(float deltaTime)
    {
        Vector3 movement = CalculateMovement();
        Move(movement * stateMachine.CrouchMovementSpeed, deltaTime);
        FaceMovementDirection(movement, deltaTime);
        
        if (stateMachine.PlayerInputReader.IsAttacking)
        {
            stateMachine.SwitchState(new PlayerAttackingState(stateMachine, 0));
            return;
        }

        if (stateMachine.PlayerInputReader.MovementValueL == Vector2.zero)
        {
            stateMachine.Animator.SetFloat(CrouchBlendParamHash, 0f, Constant_CrossFadeDuration, deltaTime);
        }

        else if (stateMachine.PlayerInputReader.MovementValueL.sqrMagnitude != 0f && stateMachine.PlayerInputReader.MovementValueL.sqrMagnitude <= 0.35f)
        {
            stateMachine.Animator.SetFloat(CrouchBlendParamHash, 0.5f, Constant_CrossFadeDuration, deltaTime);
        }
        else
        {
            stateMachine.Animator.SetFloat(CrouchBlendParamHash, 1f, Constant_CrossFadeDuration, deltaTime);
        }
    }

    public override void Exit()
    {
        Log("Exit()");
        stateMachine.PlayerInputReader.CrouchEvent -= OnCrouch;
    }

    public new Vector3 CalculateMovement()
    {
        Vector3 mainCamForwardDirection = new Vector3(stateMachine.MainCamera.transform.forward.x, 0f, stateMachine.MainCamera.transform.forward.z);
        mainCamForwardDirection.Normalize();
        Vector3 mainCamRightDirection = new Vector3(stateMachine.MainCamera.transform.right.x, 0f, stateMachine.MainCamera.transform.right.z);
        mainCamRightDirection.Normalize();

        return mainCamForwardDirection * stateMachine.PlayerInputReader.MovementValueL.y + mainCamRightDirection * stateMachine.PlayerInputReader.MovementValueL.x;
    }

    public new void FaceMovementDirection(Vector3 movement, float deltaTime)
    {
        bool isMoving = movement != Vector3.zero;
        if (!isMoving) { return; }
        else
        {
            stateMachine.transform.rotation = Quaternion.Lerp(
            stateMachine.transform.rotation, Quaternion.LookRotation(movement),
            deltaTime * stateMachine.FaceMoveDirDamping);
        }
    }

    private void OnCrouch(object sender, EventArgs e)
    {
        stateMachine.SwitchState(new PlayerFreeMoveState(stateMachine));
    }
}