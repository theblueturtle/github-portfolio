/**********************************************************************
File: PlayerBlockingState.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;

public class PlayerBlockingState : PlayerBaseState
{
    private readonly int BlockingHash = Animator.StringToHash("pClip_BlockAttack");
    private float CrossfadeDuration = 0.1f;
    private string stateID = "BLK";

    public PlayerBlockingState(PlayerStateMachine stateMachine) : base(stateMachine) { }

    private void Log(string message)
    {
        if (stateMachine.DebugLogger != null)
        {
            //stateMachine.DebugLogger.LogStateMessage(stateID, message);
        }
        else { Debug.LogError("Logger not set for = " + stateMachine.gameObject.name); }
    }

    public override void Enter()
    {
        Log("Enter()");
        stateMachine.ReportActiveState("Blocking");

        stateMachine.Animator.CrossFadeInFixedTime(BlockingHash, CrossfadeDuration);
    }

    public override void Tick(float deltaTime)
    {
        Move(deltaTime);

        if (!stateMachine.PlayerInputReader.IsBlocking)
        {
            stateMachine.SwitchState(new PlayerFreeMoveState(stateMachine));
            return;
        }
    }

    public override void Exit()
    {
        Log("Exit()");
    }
}