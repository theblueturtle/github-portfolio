/**********************************************************************
File: PlayerFreeMoveState.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using System;
using UnityEngine;

public class PlayerFreeMoveState : PlayerBaseState
{
    private readonly int FreeMoveBlendTreeHash = Animator.StringToHash("FreeMoveBlendTree");
    private readonly int FreeMoveParamHash = Animator.StringToHash("FreeMoveBlend");
    private const float Constant_CrossFadeDuration = 0.1f;
    private string stateID = "FM";

    public PlayerFreeMoveState(PlayerStateMachine stateMachine) : base(stateMachine) { }

    private void Log(string message)
    {
        if (stateMachine.DebugLogger != null)
        {
            //stateMachine.DebugLogger.LogStateMessage(stateID, message);
        }
        else { Debug.LogError("Logger not set for = " + stateMachine.gameObject.name); }
    }

    public override void Enter()
    {
        Log("Enter()");
        stateMachine.ReportActiveState("FreeMove");
        
        stateMachine.Animator.CrossFadeInFixedTime(FreeMoveBlendTreeHash, stateMachine.AnimationSmoothing);
        stateMachine.PlayerInputReader.CrouchEvent += OnCrouch;
    }

    public override void Tick(float deltaTime)
    {
        Vector3 movement = CalculateMovement();
        Move(movement * stateMachine.FreeLookMovementSpeed, deltaTime);
        FaceMovementDirection(movement, deltaTime);

        if (stateMachine.PlayerInputReader.IsAttacking)
        {
            stateMachine.SwitchState(new PlayerAttackingState(stateMachine, 0));
            return;
        }

        if (stateMachine.PlayerInputReader.IsBlocking)
        {
            stateMachine.SwitchState(new PlayerBlockingState(stateMachine));
            return;
        }

        if (stateMachine.PlayerInputReader.MovementValueL == Vector2.zero) 
        {
            stateMachine.Animator.SetFloat(FreeMoveParamHash, 0f, Constant_CrossFadeDuration, deltaTime);
            return; 
        }

        if (stateMachine.PlayerInputReader.MovementValueL.sqrMagnitude < 0.3f)
        {
            stateMachine.Animator.SetFloat(FreeMoveParamHash, 0.5f, Constant_CrossFadeDuration, deltaTime);
        }
        else
        {
            stateMachine.Animator.SetFloat(FreeMoveParamHash, 1, Constant_CrossFadeDuration, deltaTime);
        }
    }

    public override void Exit()
    {
        Log("Exit()");
    }

    private void OnCrouch(object sender, EventArgs e)
    {
        stateMachine.SwitchState(new PlayerCrouchState(stateMachine));
    }

    public new Vector3 CalculateMovement()
    {
        Vector3 mainCamForwardDirection = new Vector3(stateMachine.MainCameraTransform.forward.x, 0f, stateMachine.MainCameraTransform.forward.z);
        mainCamForwardDirection.Normalize();
        Vector3 mainCamRightDirection = new Vector3(stateMachine.MainCameraTransform.right.x, 0f, stateMachine.MainCameraTransform.right.z);
        mainCamRightDirection.Normalize();

        return mainCamForwardDirection * stateMachine.PlayerInputReader.MovementValueL.y + mainCamRightDirection * stateMachine.PlayerInputReader.MovementValueL.x;
    }

    public new void FaceMovementDirection(Vector3 movement, float deltaTime)
    {
        bool isMoving = movement != Vector3.zero;
        if (!isMoving) { return; }

        stateMachine.transform.rotation = Quaternion.Lerp(
        stateMachine.transform.rotation, Quaternion.LookRotation(movement), 
        deltaTime * stateMachine.FaceMoveDirDamping);
    }
}