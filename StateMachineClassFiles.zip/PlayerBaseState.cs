/**********************************************************************
File: PlayerBaseState.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;

public abstract class PlayerBaseState : State
{
    protected PlayerStateMachine stateMachine;
    
    public PlayerBaseState(PlayerStateMachine stateMachine) { this.stateMachine = stateMachine; }
    
    protected void Move(Vector3 motion, float deltaTime)
    {
        stateMachine.CharacterController.Move((motion) * deltaTime);
    }

    protected void Move(float deltaTime) { Move(Vector3.zero, deltaTime); }

    public Vector3 CalculateMovement()
    {
        Vector3 mainCamForwardDirection = new Vector3(stateMachine.MainCameraTransform.forward.x, 0f, stateMachine.MainCameraTransform.forward.z);
        mainCamForwardDirection.Normalize();
        Vector3 mainCamRightDirection = new Vector3(stateMachine.MainCameraTransform.right.x, 0f, stateMachine.MainCameraTransform.right.z);
        mainCamRightDirection.Normalize();

        return mainCamForwardDirection * stateMachine.PlayerInputReader.MovementValueR.y + mainCamRightDirection * stateMachine.PlayerInputReader.MovementValueR.x;
    }

    public void FaceMovementDirection(Vector3 movement, float deltaTime)
    {
        bool isMoving = movement != Vector3.zero;
        if (!isMoving) { return; }

        stateMachine.transform.rotation = Quaternion.Lerp(
        stateMachine.transform.rotation, Quaternion.LookRotation(movement),
        deltaTime * stateMachine.FaceMoveDirDamping);
    }
}
