/**********************************************************************
File: PlayerAttackingState.cs

Author: Leonardo Carrion Jr.	
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;

public class PlayerAttackingState : PlayerBaseState
{
    private Attack attack;
    private float previousFrameTime;
    private string stateID = "ATK";

    public PlayerAttackingState(PlayerStateMachine stateMachine, int attackIndex) : base(stateMachine) 
    {
        attack = stateMachine.Attacks[attackIndex];
    }

    private void Log(string message)
    {
        if (stateMachine.DebugLogger != null)
        {
            //stateMachine.DebugLogger.LogStateMessage(stateID, message);
        }
        else { Debug.LogError("Logger not set for = " + stateMachine.gameObject.name); }
    }

    public override void Enter()
    {
        Log("Enter()");
        stateMachine.ReportActiveState("Attacking");

        stateMachine.Animator.CrossFadeInFixedTime(attack.AnimationName, attack.TransitionDuration);
    }

    public override void Tick(float deltaTime)
    {
        Move(deltaTime);
        
        float normalizedTime = GetNormalizedTime(stateMachine.Animator);
        
        if(normalizedTime < 1f)
        {
            if (stateMachine.PlayerInputReader.IsAttacking) { ChainAttack(normalizedTime); }
        }
        else { stateMachine.SwitchState(new PlayerFreeMoveState(stateMachine)); }
        
        previousFrameTime = normalizedTime;
    }

    public override void Exit()
    {
        Log("Exit()");
    }

    private void ChainAttack(float normalizedTime)
    {
        if(attack.ComboStateIndex == -1) { return; }
        
        if(normalizedTime < attack.ComboAttackTime) { return; }

        stateMachine.SwitchState(new PlayerAttackingState(stateMachine, attack.ComboStateIndex));
    }
}