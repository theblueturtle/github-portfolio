/**********************************************************************
File: PlayerInputReader.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInputReader : MonoBehaviour, PlayerControls.IPlayerActions
{
    [SerializeField] private PlayerStateMachine stateMachine;
    private PlayerControls playerControls;
    private string stateID = "INPUT";

    public event EventHandler CrouchEvent;
    public bool IsAttacking { get; private set; }
    public bool IsBlocking { get; private set; }
    public bool IsCrouching { get; private set; }
    public Vector2 MovementValueL { get; private set; }
    public Vector2 MovementValueR { get; private set; }

    private void Log(string message)
    {
        if (stateMachine != null)
        {
            //stateMachine.DebugLogger.LogStateMessage(stateID, message);
        }
        else { Debug.LogError("Logger not set for \"PlayerInputReader\" component."); }
    }

    private void Start()
    {
        playerControls = new PlayerControls();

        playerControls.Player.SetCallbacks(this);
        playerControls.Player.Enable();
    }

    private void OnDestroy() { playerControls.Player.Disable(); }
    
    public void OnCinemachineCamera(InputAction.CallbackContext context) { }

    void PlayerControls.IPlayerActions.OnMove(InputAction.CallbackContext context)
    {
        MovementValueL = context.ReadValue<Vector2>();
    }

    void PlayerControls.IPlayerActions.OnCinemachineCamera(InputAction.CallbackContext context)
    {
        MovementValueR = context.ReadValue<Vector2>();
    }

    void PlayerControls.IPlayerActions.OnAttack(InputAction.CallbackContext context)
    {
        Log("InputAction \"Attack\" performed");

        if (context.performed) { IsAttacking = true; Log("Attack InputAction performed - PlayerInputReader"); }
        else if (context.canceled) { IsAttacking = false; Log("Attack InputAction canceled - PlayerInputReader"); }
    }

    void PlayerControls.IPlayerActions.OnBlock(InputAction.CallbackContext context)
    {
        Log("InputAction \"Block\" performed");

        if (context.started || context.performed)
        {
            IsBlocking = true;
            Log("Block InputAction performed - PlayerInputReader");
        }
        else if (context.canceled)
        {
            IsBlocking = false;
            Log("Block InputAction canceled - PlayerInputReader");
        }
    }

    public void OnCrouch(InputAction.CallbackContext context)
    {
        Log("InputAction \"Crouch\" performed");
        
        if (context.performed)
        {
            Log("Crouch InputAction performed - PlayerInputReader");

            IsCrouching = !IsCrouching;
            CrouchEvent?.Invoke(this, EventArgs.Empty);
        }
    }
}