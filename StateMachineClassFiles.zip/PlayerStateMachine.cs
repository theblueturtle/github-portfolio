/**********************************************************************
File: PlayerStateMachine.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using TMPro;
using UnityEngine;

public class PlayerStateMachine : StateMachine
{
    #region Members
    [field: Header("DEPENDENCIES:")]
    [field: SerializeField] public GameObject MainCamera { get; private set; }
    [field: SerializeField] public CharacterController CharacterController { get; private set; }
    [field: SerializeField] public Animator Animator { get; private set; }
    [field:SerializeField] public PlayerInputReader PlayerInputReader { get; private set; }
    [field: SerializeField] public TextMeshProUGUI StateMachineStatus { get; private set; }
    [field: SerializeField] public Attack[] Attacks { get; private set; }
    [field: SerializeField] public float FreeLookMovementSpeed { get; private set; }
    [field: SerializeField] public float CrouchMovementSpeed { get; private set; }
    [field: SerializeField] public float FaceMoveDirDamping { get; private set; }
    [field: SerializeField] public float AnimationSmoothing { get; private set; }
    public Transform MainCameraTransform { get; private set; }

    [field: Space(5)]

    [field: Header("DEBUG:")]
    [field: SerializeField] public DebugLogger DebugLogger { get; private set; }
    #endregion

    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        MainCameraTransform = Camera.main.transform;
    }

    private void Start() { SwitchState(new PlayerFreeMoveState(this)); }

    public void ReportActiveState(string reportedState) { StateMachineStatus.text = reportedState; }
}