/**********************************************************************
File: State.cs

Author: Leonardo Carrion Jr.
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;

public abstract class State
{
    public abstract void Enter();
    public abstract void Tick(float deltaTime);
    public abstract void Exit();

    protected float GetNormalizedTime(Animator animator)
    {
        AnimatorStateInfo currentClipInfo = animator.GetCurrentAnimatorStateInfo(0);
        AnimatorStateInfo nextClipInfo = animator.GetNextAnimatorStateInfo(0);

        if (animator.IsInTransition(0) && nextClipInfo.IsTag("Attack"))
        {
            return nextClipInfo.normalizedTime;
        }
        else if (!animator.IsInTransition(0) && currentClipInfo.IsTag("Attack"))
        {
            return currentClipInfo.normalizedTime;
        }
        else { return 0f; }
    }
}