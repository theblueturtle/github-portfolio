/**********************************************************************
File: Stats2JSON.cs

Author: Leonardo Carrion Jr.	
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;
using UnityEditor;
using System.IO;
using System;
using System.Collections.Generic;

#if UNITY_EDITOR

public class Stats2JSON : EditorWindow
{
    private class MySerializationWrapper
    {
        public List<StatData> MasterStatDataList;
    }

    public List<StatData> StatsSODataStructList = new List<StatData>();

    [SerializeField] private PlayerStats playerStatsSO;

    [Space(10)]

    [SerializeField] private EnemyStats enemyStatsSO;

    private SerializedObject serializedObject;
    private string pathToSaveFile = default;
    private string pathToLoadedFile = default;

    public string helpMessage;

    private string[] messages = new string[]
        {
            "Stats2JSON - How To || First, drag in a \"PlayerStats\" OR \"EnemyStats\" asset from the project directory. Only one ScriptableObject should ever be referenced at one time. Next, select the \"Save Stats Data\" button below and choose a destination to save out a JSON file containing all the stats in the referenced ScriptableObject. Alternatively, you can select the \"Load Stats Data\" button and choose a JSON file from disk to override existing stats data.",
            "Saved data to designated location!",
            "Loaded stat data from specified JSON file!"
        };

    [MenuItem("Tools/Leonardo Carrion Demo/Stats 2 JSON")]
    public static void LaunchUtilWindow()
    {
        GetWindow(typeof(Stats2JSON));
    }

    private void OnEnable()
    {
        serializedObject = new SerializedObject(this);
    }

    private void OnGUI()
    {
        serializedObject.Update();

        EditorGUIUtility.labelWidth = 160;

        GUILayout.Label("Save SO Data To JSON & Read It Back In", EditorStyles.boldLabel);

        SerializedProperty playerDataSO = serializedObject.FindProperty("playerStatsSO"); 
        EditorGUILayout.PropertyField(playerDataSO, true);
        serializedObject.ApplyModifiedProperties();

        SerializedProperty enemyDataSO = serializedObject.FindProperty("enemyStatsSO"); 
        EditorGUILayout.PropertyField(enemyDataSO, true);
        serializedObject.ApplyModifiedProperties();

        EditorGUILayout.HelpBox(helpMessage, MessageType.Info);

        if (GUILayout.Button("Save Stats Data"))
        {
            if (playerStatsSO && enemyStatsSO || !playerStatsSO && !enemyStatsSO) { PrintHelpMessage(0); return; }

            pathToSaveFile = EditorUtility.SaveFilePanel("Save Scriptable Object To JSON", "", "statData.json", "json");

            if (!string.IsNullOrWhiteSpace(pathToSaveFile))
            {
                SaveSOData();
                PrintHelpMessage(1);
            }
        }

        GUILayout.Space(20);

        if (GUILayout.Button("Load Stats Data"))
        {
            if (playerStatsSO && enemyStatsSO) { PrintHelpMessage(0); return; }

            pathToLoadedFile = EditorUtility.OpenFilePanel("Select Save File", "", "json");

            if (!string.IsNullOrWhiteSpace(pathToLoadedFile))
            {
                ReloadData();
                PrintHelpMessage(2);
            }
        }
    }

    private void SaveSOData()
    {
        if (playerStatsSO && !enemyStatsSO)
        {
            StatsSODataStructList = playerStatsSO.RetrievePlayerStatData();
        }
        else if (!playerStatsSO && enemyStatsSO)
        {
            StatsSODataStructList = enemyStatsSO.RetrieveEnemyStatData();
        }

        string json = JsonUtility.ToJson(new MySerializationWrapper { MasterStatDataList = StatsSODataStructList }, true);
        File.WriteAllText(pathToSaveFile, json);
    }

    private void ReloadData()
    {
        if (File.Exists(pathToLoadedFile))
        {
            string json = File.ReadAllText(pathToLoadedFile);

            MySerializationWrapper data = JsonUtility.FromJson<MySerializationWrapper>(json);

            Dictionary<string, int> dictionaryInt = new Dictionary<string, int>();
            Dictionary<string, float> dictionaryFloat = new Dictionary<string, float>();

            if (playerStatsSO && !enemyStatsSO)
            {
                ProcessLoadedPlayerData(data, dictionaryInt, dictionaryFloat);
            }
            else if (!playerStatsSO && enemyStatsSO)
            {
                ProcessLoadedEnemyData(data, dictionaryInt, dictionaryFloat);
            }
        }
    }

    private void ProcessLoadedPlayerData(MySerializationWrapper data, Dictionary<string, int> dictionaryInt, Dictionary<string, float> dictionaryFloat)
    {
        foreach (var item in data.MasterStatDataList)
        {
            if (item.Type == "Int32")
            {
                dictionaryInt.Add(item.Name, int.Parse(item.Value));
            }
            else if (item.Type == "Single")
            {
                dictionaryFloat.Add(item.Name, float.Parse(item.Value));
            }

            Type typeGeneralProperties = playerStatsSO.generalProperties.GetType();
            Type typeCombatProperties = playerStatsSO.combatProperties.GetType();

            foreach (KeyValuePair<string, int> entry in dictionaryInt)
            {
                if (typeGeneralProperties.GetProperty(entry.Key) != null)
                {
                    playerStatsSO.generalProperties.InjectStatData(entry.Key, entry.Value, 0f);
                }
                else if (typeCombatProperties.GetProperty(entry.Key) != null)
                {
                    playerStatsSO.combatProperties.InjectStatData(entry.Key, entry.Value, 0f);
                }
            }

            foreach (KeyValuePair<string, float> entry in dictionaryFloat)
            {
                if (typeGeneralProperties.GetProperty(entry.Key) != null)
                {
                    playerStatsSO.generalProperties.InjectStatData(entry.Key, 0, entry.Value);
                }
                else if (typeCombatProperties.GetProperty(entry.Key) != null)
                {
                    playerStatsSO.combatProperties.InjectStatData(entry.Key, 0, entry.Value);
                }
            }
        }

        EditorUtility.SetDirty(playerStatsSO);
    }

    private void ProcessLoadedEnemyData(MySerializationWrapper data, Dictionary<string, int> dictionaryInt, Dictionary<string, float> dictionaryFloat)
    {
        foreach (var item in data.MasterStatDataList)
        {
            if (item.Type == "Int32")
            {
                dictionaryInt.Add(item.Name, int.Parse(item.Value));
            }
            else if (item.Type == "Single")
            {
                dictionaryFloat.Add(item.Name, float.Parse(item.Value));
            }

            Type typeGeneralProperties = enemyStatsSO.generalProperties.GetType();
            Type typeCombatProperties = enemyStatsSO.combatProperties.GetType();

            foreach (KeyValuePair<string, int> entry in dictionaryInt)
            {
                if (typeGeneralProperties.GetProperty(entry.Key) != null)
                {
                    enemyStatsSO.generalProperties.InjectStatData(entry.Key, entry.Value, 0f);
                }
                else if (typeCombatProperties.GetProperty(entry.Key) != null)
                {
                    enemyStatsSO.combatProperties.InjectStatData(entry.Key, entry.Value, 0f);
                }
            }

            foreach (KeyValuePair<string, float> entry in dictionaryFloat)
            {
                if (typeGeneralProperties.GetProperty(entry.Key) != null)
                {
                    enemyStatsSO.generalProperties.InjectStatData(entry.Key, 0, entry.Value);
                }
                else if (typeCombatProperties.GetProperty(entry.Key) != null)
                {
                    enemyStatsSO.combatProperties.InjectStatData(entry.Key, 0, entry.Value);
                }
            }
        }
        EditorUtility.SetDirty(enemyStatsSO);
    }

    public void PrintHelpMessage(int index)
    {
        helpMessage = messages[index];
    }
}

#endif