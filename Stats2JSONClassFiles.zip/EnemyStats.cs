﻿/**********************************************************************
File: EnemyStats.cs

Author: Leonardo Carrion Jr.	
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using UnityEngine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;

[CreateAssetMenu(fileName = "EnemyStats", menuName = "ScriptableObjects/Stats/EnemyStats")]
public class EnemyStats : ScriptableObject
{
    [Serializable]
    public class GeneralProperties
    {
        [field: SerializeField, Tooltip("Enemy's level.")]
        public int Level { get; private set; } = 1;

        [field: SerializeField]
        public int XPAwardBase { get; private set; } = 4;

        public void ClearStatValues()
        {
            Level = 0;
            XPAwardBase = 0;
        }

        public void InjectStatData(string nameOfPropertyInThisClass, int valueInt, float valueFloat)
        {
            Type type = this.GetType();

            PropertyInfo property = type.GetProperty(nameOfPropertyInThisClass, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);

            if (property != null && property.PropertyType == typeof(Int32))
            {
                if (property.CanWrite){property.SetValue(this, valueInt);}
            }
            else if (property != null && property.PropertyType == typeof(Single))
            {
                if (property.CanWrite){property.SetValue(this, valueFloat);}
            }
        }
    }

    [Serializable]
    public class CombatProperties
    {
        [field: SerializeField]
        public int HealthBase { get; private set; } = 50;

        [field: SerializeField]
        public int HealthPerLevel { get; private set; } = 20;

        [field: SerializeField]
        public float EquipmentHealthBonus { get; private set; } = 1.5f;

        [field: Space(10)]

        [field: SerializeField]
        public float BlockDamageReduction { get; private set; } = 0.5f;

        [field: SerializeField]
        public float BlockCooldown { get; private set; } = 5f;

        [field: Space(10)]

        [field: SerializeField]
        public int Constitution { get; private set; } = 5;

        [field: SerializeField]
        public float Strength { get; private set; } = 4;

        [field: SerializeField]
        public float Intelligence { get; private set; } = 3;

        [field: Space(10)]

        [field: SerializeField]
        public int EnemyDamagePerLevel { get; private set; } = 4;

        [field: SerializeField]
        public float StaggerResistance { get; private set; } = 0.1f;

        public void ClearStatValues()
        {
            HealthBase = 0;
            HealthPerLevel = 0;
            EquipmentHealthBonus = 0;
            BlockDamageReduction = 0;
            BlockCooldown = 0;
            Constitution = 0;
            Strength = 0;
            Intelligence = 0;
            EnemyDamagePerLevel = 0;
            StaggerResistance = 0;
        }

        public void InjectStatData(string nameOfPropertyInThisClass, int valueInt, float valueFloat)
        {
            Type type = this.GetType();

            PropertyInfo property = type.GetProperty(nameOfPropertyInThisClass, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);

            if (property != null && property.PropertyType == typeof(Int32))
            {
                if (property.CanWrite){property.SetValue(this, valueInt);}
            }
            else if (property != null && property.PropertyType == typeof(Single))
            {
                if (property.CanWrite){property.SetValue(this, valueFloat);}
            }
        }
    }

    /*---------------------------------------------------------------------------------*/

    [field: Header("GENERAL PROPERTIES:")]
    public GeneralProperties generalProperties;

    [field: Header("COMBAT PROPERTIES:")]
    public CombatProperties combatProperties;

    /*---------------------------------------------------------------------------------*/

    public List<StatData> RetrieveEnemyStatData()
    {
        List<StatData> MasterPlayerDataList = new List<StatData>();

        foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(typeof(GeneralProperties)))
        {
            StatData container;

            string name = descriptor.Name;
            object value = descriptor.GetValue(generalProperties);
            string propertyType = descriptor.PropertyType.Name;

            container.Name = name;
            container.Value = value.ToString();
            container.Type = propertyType;

            MasterPlayerDataList.Add(container);
        }

        foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(typeof(CombatProperties)))
        {
            StatData container;

            string name = descriptor.Name;
            object value = descriptor.GetValue(combatProperties);
            string propertyType = descriptor.PropertyType.Name;

            container.Name = name;
            container.Value = value.ToString();
            container.Type = propertyType;

            MasterPlayerDataList.Add(container);
        }

        return MasterPlayerDataList;
    }

    [ContextMenu("Clear All Data")]
    public void ClearAllData()
    {
        generalProperties.ClearStatValues();
        combatProperties.ClearStatValues();
    }
}