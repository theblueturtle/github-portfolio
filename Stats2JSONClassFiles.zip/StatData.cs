/**********************************************************************
File: StatData.cs

Author: Leonardo Carrion Jr.	
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

[System.Serializable]
public struct StatData
{
    public string Name;
    public string Value;
    public string Type;
}