/**********************************************************************
File: DnD5thEditionWebScraper.cs

Author: Leonardo Carrion Jr.	
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

namespace D_D5thEdition_WebScraper
{
    public partial class DnD5thEditionWebScraper : Form
    {
        private DnDAPILogic dndAPILogicComponent;

        public DnD5thEditionWebScraper()
        {
            InitializeComponent();
            dndAPILogicComponent = new DnDAPILogic();
            pictureBoxEntry.Image = Properties.Resources.dndImageDefault;
            progressBarScraper.Visible = false;
        }

        private async void buttonExecuteScrape_Click(object sender, EventArgs e)
        {
            string userInputRaw = textBoxUserInput.Text;
            string userInputValidated = textBoxUserInput.Text;
            userInputValidated = userInputValidated.ToLower();
            userInputValidated = userInputValidated.Replace(" ", "-");

            var progress = new Progress<int>(value =>
            {
                progressBarScraper.Value = value;
            });

            progressBarScraper.Visible = true;

            string result = await dndAPILogicComponent.ExecuteScrape(progress, userInputValidated, userInputRaw);

            if (result.Contains("Request Failed:"))
            {
                richTextBoxHelp.SelectionColor = Color.Red;
                richTextBoxHelp.AppendText(result);
            }
            else
            {
                richTextBoxHelp.SelectionColor = Color.Black;
                richTextBoxHelp.AppendText("Success: Database entry found for \"" + userInputRaw + "\"\n");

                dndAPILogicComponent.PopulateData(labelMonsterName, dataGridViewDisplay, result);

                System.Drawing.Image imageResponse = dndAPILogicComponent.DownloadMonsterImage();
                if (imageResponse != null) { pictureBoxEntry.Image = imageResponse; }
                else { pictureBoxEntry.Image = Properties.Resources.dndImageDefault; }
            }

            progressBarScraper.Visible = false;
        }

        private void buttonInfo_Click(object sender, EventArgs e)
        {
            InfoPopupForm infoPopupForm = new InfoPopupForm();
            infoPopupForm.ShowDialog();
        }
    }
}