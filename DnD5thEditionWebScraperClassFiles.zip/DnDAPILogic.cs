﻿/**********************************************************************
File: DnDAPILogic.cs

Author: Leonardo Carrion Jr.	
Linktree: https://linktr.ee/LeonardoCarrion
Date Last Modified: 10/31/24
	
***********************************************************************/

using System.Text.Json;

namespace D_D5thEdition_WebScraper
{
    internal class DnDAPILogic
    {
        public DnDAPILogic() { }

        private string monsterImageURL = string.Empty;

        public async Task<string> ExecuteScrape(IProgress<int> progress, string userInput, string userInputRaw)
        {
            progress?.Report(15);
            
            using (var client = new HttpClient())
            {
                string apiUrl = "https://www.dnd5eapi.co/api/monsters/" + userInput;

                progress?.Report(35);

                HttpResponseMessage response = await client.GetAsync(apiUrl);

                progress?.Report(60);

                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();

                    progress?.Report(100);
                    
                    return content;
                }
                else
                {
                    string contentError = string.Format("Request Failed: Reason - \"" + userInputRaw + "\" {0}\n", response.ReasonPhrase);

                    progress?.Report(100);
                    
                    return contentError;
                }
            }
        }

        public void PopulateData(Label monsterNameLabel, DataGridView dataGridViewControl, string responseContent)
        {
            #region Data Formatting
            string bufferPipe = " | ";

            var jsonString = JsonDocument.Parse(responseContent);

            string monsterName = jsonString.RootElement.GetProperty("name").ToString();

            string typeLabel = "Type: ";
            string typeValue = jsonString.RootElement.GetProperty("type").ToString();
            string type = typeLabel + typeValue;

            string alignmentLabel = "Align: ";
            string alignmentValue = jsonString.RootElement.GetProperty("alignment").ToString();
            string alignment = alignmentLabel + alignmentValue;

            string armorClassLabel = "Armor Class: ";
            string armorClassType = jsonString.RootElement.GetProperty("armor_class")[0].GetProperty("type").ToString().ToUpper();
            string armorClassValue = jsonString.RootElement.GetProperty("armor_class")[0].GetProperty("value").GetInt32().ToString();
            string armorClass = armorClassLabel + armorClassValue + bufferPipe + armorClassType;

            string hitPointsLabel = "Hit Points: ";
            string hitPointsValue = jsonString.RootElement.GetProperty("hit_points").GetInt32().ToString();
            string hitPoints = hitPointsLabel + hitPointsValue;

            string speedLabel = "Speed: ";
            string speedValue = string.Empty;
            string speedType = string.Empty;

            if (jsonString.RootElement.TryGetProperty("speed", out JsonElement speedElement))
            {
                JsonProperty firstProperty = speedElement.EnumerateObject().First();

                speedType = firstProperty.Name;
                var value = firstProperty.Value.GetString();
                if(value != null) { speedValue = value; }
            }
            else { speedValue = "N/A"; speedType = "N/A"; }

            string strengthLabel = "Strength: ";
            string strengthValue = jsonString.RootElement.GetProperty("strength").ToString();
            string strength = strengthLabel + strengthValue;

            string dexterityLabel = "Dexterity: ";
            string dexterityValue = jsonString.RootElement.GetProperty("dexterity").ToString();
            string dexterity = dexterityLabel + dexterityValue;

            string constitutionLabel = "Constitution: ";
            string constitutionValue = jsonString.RootElement.GetProperty("constitution").ToString();
            string constitution = constitutionLabel + constitutionValue;

            string intelligenceLabel = "Intelligence: ";
            string intelligenceValue = jsonString.RootElement.GetProperty("intelligence").ToString();
            string intelligence = intelligenceLabel + intelligenceValue;

            string wisdomLabel = "Wisdom: ";
            string wisdomValue = jsonString.RootElement.GetProperty("wisdom").ToString();
            string wisdom = wisdomLabel + wisdomValue;

            string charismaLabel = "Charisma: ";
            string charismaValue = jsonString.RootElement.GetProperty("charisma").ToString();
            string charisma = charismaLabel + charismaValue;

            List<string> specialAbilitiesCollection = new List<string>();

            if (jsonString.RootElement.TryGetProperty("special_abilities", out JsonElement specialAbilitiesElement))
            {
                foreach (JsonElement property in specialAbilitiesElement.EnumerateArray())
                {
                    string abilityName = property.GetProperty("name").ToString();
                    specialAbilitiesCollection.Add(abilityName);
                }
            }

            List<string> actionsCollection = new List<string>();

            if (jsonString.RootElement.TryGetProperty("actions", out JsonElement actionsElement))
            {
                foreach (JsonElement property in actionsElement.EnumerateArray())
                {
                    string actionName = property.GetProperty("name").ToString();
                    actionsCollection.Add(actionName);
                }
            }

            try
            {
                string imageURL = jsonString.RootElement.GetProperty("image").ToString();
                if (!string.IsNullOrEmpty(imageURL)) { monsterImageURL = imageURL; }
            }
            catch (Exception) { monsterImageURL = string.Empty; }
            #endregion

            #region Populate Data Grid View
            dataGridViewControl.Columns.Clear();
            dataGridViewControl.CellBorderStyle = DataGridViewCellBorderStyle.None;

            dataGridViewControl.Columns.Add("Column1", string.Empty);
            dataGridViewControl.Columns.Add("Column2", string.Empty);
            dataGridViewControl.Columns.Add("Column3", string.Empty);

            dataGridViewControl.Rows.Add(monsterName);
            dataGridViewControl.CurrentCell = dataGridViewControl.Rows[0].Cells[0];

            InsertHeaderRow(dataGridViewControl, "Nature");
            int natureRowIndex = dataGridViewControl.Rows.Add(type, alignment);
            DataGridViewRow natureRow = dataGridViewControl.Rows[natureRowIndex];
            natureRow.Height = 32;

            InsertHeaderRow(dataGridViewControl, "Defensive Stats");
            dataGridViewControl.Rows.Add(armorClass, hitPoints);
            dataGridViewControl.Rows.Add(speedLabel + speedType + bufferPipe + speedValue);

            InsertHeaderRow(dataGridViewControl, "Attributes");
            int attributeRow1Index = dataGridViewControl.Rows.Add(strength, dexterity, constitution);
            DataGridViewRow attributeRow1 = dataGridViewControl.Rows[attributeRow1Index];
            attributeRow1.Height = 32;
            int attributeRow2Index = dataGridViewControl.Rows.Add(intelligence, wisdom, charisma);
            DataGridViewRow attributeRow2 = dataGridViewControl.Rows[attributeRow2Index];
            attributeRow2.Height = 32;

            InsertHeaderRow(dataGridViewControl, "Special Abilities");
            int maxAllowedSpecialAbilities = 3;
            int abilitiesToList;

            if (specialAbilitiesCollection.Count == 0) { /*do nothing*/ }
            else if (specialAbilitiesCollection.Count <= maxAllowedSpecialAbilities)
            {
                abilitiesToList = specialAbilitiesCollection.Count;

                InsertCellData(dataGridViewControl, specialAbilitiesCollection, abilitiesToList);
            }
            else
            {
                abilitiesToList = maxAllowedSpecialAbilities;

                InsertCellData(dataGridViewControl, specialAbilitiesCollection, abilitiesToList);
            }

            InsertHeaderRow(dataGridViewControl, "Actions");
            int maxAllowedActions = 3;
            int actionsToList;

            if (actionsCollection.Count == 0) { /*do nothing*/ }
            else if (actionsCollection.Count <= maxAllowedActions)
            {
                actionsToList = actionsCollection.Count;

                InsertCellData(dataGridViewControl, actionsCollection, actionsToList);
            }
            else
            {
                actionsToList = maxAllowedActions;

                InsertCellData(dataGridViewControl, actionsCollection, actionsToList);
            }
            #endregion

            /*Big red label above image*/
            monsterNameLabel.Text = monsterName;
        }

        private void InsertHeaderRow(DataGridView dataGridViewControl, string headerText)
        {
            int headerRowIndex = dataGridViewControl.Rows.Add();
            DataGridViewRow headerRow = dataGridViewControl.Rows[headerRowIndex];

            headerRow.Cells[0].Value = headerText;
            headerRow.Cells[0].Style.Font = new System.Drawing.Font("Arial", 14, FontStyle.Bold);
            headerRow.Cells[0].Style.Alignment = DataGridViewContentAlignment.TopLeft;
            headerRow.Cells[0].Style.BackColor = Color.LightGray;

            for (int i = 1; i < dataGridViewControl.Columns.Count; i++)
            {
                headerRow.Cells[i].Value = string.Empty;
                headerRow.Cells[i].Style.BackColor = Color.LightGray;
                headerRow.Cells[i].Style.ForeColor = Color.LightGray; 
                headerRow.Cells[i].Style.SelectionBackColor = Color.LightGray;
                headerRow.Cells[i].Style.SelectionForeColor = Color.LightGray;
                headerRow.Cells[i].ReadOnly = true;
            }
        }

        private void InsertCellData(DataGridView dataGridViewControl, List<string> collection, int count)
        {
            int emptyRowIndex = dataGridViewControl.Rows.Add();
            DataGridViewRow row = dataGridViewControl.Rows[emptyRowIndex];
            row.Height = 32;

            for (int i = 0; i < count; i++)
            {
                row.Cells[i].Value = collection[i];
            }
        }

        public Image DownloadMonsterImage()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var response = client.GetAsync("https://www.dnd5eapi.co" + monsterImageURL).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var imageBytes = response.Content.ReadAsByteArrayAsync().Result;
                        using (var memoryStream = new MemoryStream(imageBytes))
                        {
                            Image image = Image.FromStream(memoryStream);
                            Image imageResized = ResizeImage(image);

                            return imageResized;
                        }
                    }
                }
            }
            catch (Exception) { return null; }

            return null;
        }

        public static Image ResizeImage(Image originalImage)
        {
            int targetWidth = 292;
            int targetHeight = targetWidth;

            Bitmap resizedImage = new Bitmap(targetWidth, targetHeight);

            using (Graphics graphics = Graphics.FromImage(resizedImage))
            {
                graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

                graphics.DrawImage(originalImage, 0, 0, targetWidth, targetHeight);
            }

            return resizedImage;
        }
    }
}